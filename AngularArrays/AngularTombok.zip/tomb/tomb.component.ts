import { Component } from '@angular/core';

@Component({
  selector: 'app-tomb',
  templateUrl: './tomb.component.html',
  styleUrls: ['./tomb.component.css']
})
export class TombComponent {

  BevasarloLista: string[] = ["alma", "szilva", "banán", "ananász", "kiwi"]


}
